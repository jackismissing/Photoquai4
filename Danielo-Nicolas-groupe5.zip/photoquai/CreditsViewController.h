//
//  CreditsViewController.h
//  photoquai
//
//  Created by Nicolas on 27/01/13.
//  Copyright (c) 2013 Groupe 5 PHQ Gobelins CDNL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditsViewController : UIViewController

@end
