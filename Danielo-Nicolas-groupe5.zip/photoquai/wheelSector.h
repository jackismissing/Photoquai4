//
//  wheelSector.h
//  photoquai
//
//  Created by Nicolas on 17/01/13.
//  Copyright (c) 2013 Groupe 5 PHQ Gobelins CDNL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface wheelSector : NSObject

@property float minValue;
@property float maxValue;
@property float midValue;
@property int sector;

@end
